<?php
namespace BooklyLite\Lib\Payment;

use BooklyLite\Lib;

/**
 * Class TwoCheckout
 */
class TwoCheckout
{

}