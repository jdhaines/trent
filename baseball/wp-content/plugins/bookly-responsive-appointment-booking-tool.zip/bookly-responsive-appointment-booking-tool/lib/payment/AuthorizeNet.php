<?php
namespace BooklyLite\Lib\Payment;

use BooklyLite\Lib;

/**
 * Class AuthorizeNet
 * @package BooklyLite\Lib\Payment
 */
class AuthorizeNet
{

}