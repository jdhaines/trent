<?php
namespace BooklyLite\Lib\Payment;

use BooklyLite\Lib;

/**
 * Class Payson
 * @package BooklyLite\Lib\Payment
 */
class Payson
{

}