<?php
namespace BooklyLite\Lib\Payment;

use BooklyLite\Lib;

/**
 * Class PayuLatam
 */
class PayuLatam
{

}