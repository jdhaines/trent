<?php
namespace BooklyLite\Lib\Payment;

use BooklyLite\Lib;

/**
 * Class Mollie
 */
class Mollie
{

}