<?php
namespace BooklyLite\Lib\Payment;

use BooklyLite\Lib;

/**
 * Class PayPal
 * @package BooklyLite\Lib\Payment
 */
class PayPal
{

}