<?php
namespace BooklyLite\Frontend\Modules\Payson;

use BooklyLite\Lib;

/**
 * Class Controller
 * @package BooklyLite\Frontend\Modules\Payson
 */
class Controller extends Lib\Base\Controller
{
}