<?php
namespace BooklyLite\Frontend\Modules\TwoCheckout;

use BooklyLite\Lib;

/**
 * Class Controller
 * @package BooklyLite\Frontend\Modules\TwoCheckout
 */
class Controller extends Lib\Base\Controller
{
}