<?php
namespace BooklyLite\Frontend\Modules\Mollie;

use BooklyLite\Lib;

/**
 * Class Controller
 * @package BooklyLite\Frontend\Modules\Mollie
 */
class Controller extends Lib\Base\Controller
{
}