<?php
namespace BooklyLite\Frontend\Modules\PayuLatam;

use BooklyLite\Lib;

/**
 * Class Controller
 * @package BooklyLite\Frontend\Modules\PayuLatam
 */
class Controller extends Lib\Base\Controller
{
}