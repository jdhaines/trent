<?php
namespace BooklyLite\Frontend\Modules\AuthorizeNet;

use BooklyLite\Lib;

/**
 * Class Controller
 * @package BooklyLite\Frontend\Modules\AuthorizeNet
 */
class Controller extends Lib\Base\Controller
{

}
