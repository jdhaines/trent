<?php
namespace BooklyLite\Frontend\Modules\WooCommerce;

use BooklyLite\Lib;

/**
 * Class Controller
 * @package BooklyLite\Frontend\Modules\WooCommerce
 */
class Controller extends Lib\Base\Controller
{
}