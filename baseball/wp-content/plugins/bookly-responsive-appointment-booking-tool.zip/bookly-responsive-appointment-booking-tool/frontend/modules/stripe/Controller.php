<?php
namespace BooklyLite\Frontend\Modules\Stripe;

use BooklyLite\Lib;

/**
 * Class Controller
 * @package BooklyLite\Frontend\Modules\Stripe
 */
class Controller extends Lib\Base\Controller
{
}