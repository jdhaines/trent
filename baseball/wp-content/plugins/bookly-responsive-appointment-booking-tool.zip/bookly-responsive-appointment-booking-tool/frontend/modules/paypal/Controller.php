<?php
namespace BooklyLite\Frontend\Modules\Paypal;

use BooklyLite\Lib;

/**
 * Class Controller
 * @package BooklyLite\Frontend\Modules\PayPal
 */
class Controller extends Lib\Base\Controller
{
}